#ifndef DJI_H
#define DJI_H

#include "game.h"
#include "linkedList.h"

#define SOMMET 121

Rect dji(int cost[][SOMMET], int source, int target );
Rect miin(Rect t[], int n);

#endif

#include<iostream>
#include<fstream>
#include<cstdlib>
#include <sstream>

void updateFile();

namespace patch
{
template < typename T > std::string to_string( const T& n )
{
    std::ostringstream stm ;
    stm << n ;
    return stm.str() ;
}
}

using namespace std;

class Player {
private:
    std::string name;
    int moveCount;
public:
    // getter setter moveCount
    int getMoveCount(){ return moveCount; }
    void setMoveCount(int m) { this->moveCount = m; }
    // getter setter name
    std::string getName(){ return name; }
    void setName(std::string n) { this->name = n; }
    // save straightway
    void saveToFile(std::string n, int p) {
        fstream myfile;
        myfile.open ("stat.txt", ios::app);
        if (myfile.is_open())
        {
            cout << "fopen" << '\n';
            myfile << patch::to_string(p) << ' ' << n << '\n';
        }
        myfile.close();
        updateFile();
    }

    // set before save
    void saveToFile() {
        fstream myfile;
        myfile.open ("stat.txt", ios::app);
        if (myfile.is_open())
        {
            cout << "fopen" << '\n';
            myfile << patch::to_string(this->moveCount) << ' ' << this->name << '\n';
        }
        myfile.close();
        updateFile();
    }
};

void updateFile()
{
    int i,j,a,countloop;
    string name[7];
    string point[7];
    string temp;
    fstream myfile;

    // re-arrange data
    myfile.open ("stat.txt", ios::in);
    countloop=0;
    if (myfile.is_open())
    {
        i=0;
        cout << "fopen" << '\n';
        while ( !myfile.eof() )
        {
            myfile >> point[i] >> name[i];
            i++;
            countloop++;
        }

        // sort point
        for(i=0; i<countloop; i++)
        {
            for(j=0; j<i; j++)
            {
                if(point[i] < point[j] && countloop>1)
                {
                    temp = point[i];
                    point[i] = point[j];
                    point[j] = temp;

                    temp = name[i];
                    name[i] = name[j];
                    name[j] = temp;
                }
            }
        }

        // delete duplicate name
        countloop--;
        for(i=0; i<countloop; i++)
        {
            for(j=0; j<i; j++)
            {
                if(name[i] == name[j])
                {
                    for(a=0; a<countloop-i-1 ; a++)
                    {
                        name[i+a] = name[i+a+1];
                        point[i+a] = point[i+a+1];
                    }
                    countloop--;
                    i=0;
                    break;
                }
            }
        }
    }
    myfile.close();

    // re-write data to file
    myfile.open ("stat.txt", ios::out);
    if (myfile.is_open())
    {
        i=0;
        while( countloop !=0 && i<5 )
        {
            cout << point[i] << ' ' << name[i] << countloop <<endl;
            myfile << point[i] << ' ' << name[i] <<endl;
            i++;
            countloop--;
        }
    }
    myfile.close();
}

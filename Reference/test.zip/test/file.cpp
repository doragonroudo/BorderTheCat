//#include<iostream>
//#include<fstream>
//#include<cstdlib>
//#include<sstream>
//#include "Player.hpp"
//
//using namespace std;
//
//int main()
//{
//    Player p1;
//    // save straightway
////    p1.saveToFile("kmp", 90);
//    //updateFile();
//    // set before save
////    p1.setMoveCount(56);
////    p1.setName("Joke");
////    p1.saveToFile();
//
//    system("PAUSE");
//    return 0;
//}
